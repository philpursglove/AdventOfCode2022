﻿using NUnit.Framework;

namespace $safeprojectname$
{
    [TestFixture]
    public class UnitTests
    {
    }
}
